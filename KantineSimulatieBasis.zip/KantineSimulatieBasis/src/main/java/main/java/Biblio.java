//package main.java;
//import java.util.ArrayList;
//
//
//public class Biblio {
//    private Dienblad dienblad;
//
//
//
//    public Biblio (){
//
//
//    }
//
//    public static void createArtikelen (){
//
//        Artikel artikel = new Artikel("Kaasbroodje" , 595);
//        Artikel artikel2 = new Artikel("Optimel" , 300);
//        Artikel artikel3 = new Artikel("Appel" , 225);
//        Artikel artikel4 = new Artikel("Frikandel" , 685);
//        Artikel artikel5 = new Artikel("Kauwgum" , 540);
//        Artikel artikel6 = new Artikel("Pakje chips" , 250);
//
//    }
//
//
//
//
//
//}